#!/bin/bash
echo "Running PyQt5 Login Application..."
python3 main.py
